<html>
<title>
</title>
  <head>
    <link rel="stylesheet" type="text/css" href="branch_add_style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  </head>
  <div class="center">
  <form>
  <ul class="form-style-1">
      <li>
          <label>Update Branch Info <span class="">*</span></label>

      </li>
      <li>
          <label>Pondo ID <span class="required">*</span></label>
          <input id="in_pondoID" type="text" name="pondoID" class="field-divided" placeholder="ID" />
      </li>
      <li>
        <label>Branch Name <span class="required">*</span></label>
        <input id="in_branchName" type="text" name="branchName" class="field-divided" placeholder="Branch Name" /></li>

      <li>
          <label>Number of PC <span class="required">*</span></label>
          <input id="in_numberofPC" type="text" name="field3" class="field-divided" placeholder="Number of PC"/>
      </li>
      <li>
          <label>Group</label>
          <div class="group"></div>
      </li>

      <li>
          <input type="Submit" value="Add Branch" onclick="return addBranch();"/>
      </li>
      <li>
          <input type="Submit" value="Update Branch" onclick="return show_confirm();"/>
      </li>

  </ul>
  <div class="output"></div>
  </form>
</div>
<script>
$(document).ready(function () {
    readRecords(); // calling function
});

function readRecords() {

    var datadata="";
    $.post("ajax/readGroups.php", {
    }, function (data, status) {
        //datadata=data;
        // console.log(data);
        $(".group").html(data);
        // console.log(data);;
    });

}
function show_confirm()
{
     var r=confirm("Do You Really want to Refund money! Press ok to Continue ");
     if (r==true)
       {
       window.location="branch_update.php";
       return true;
       }
          else
       {
       alert("You pressed Cancel!");
       }
}
function addBranch() {

  var pondoID = $("#in_pondoID").val();
  var branchName = $("#in_branchName").val();
  var pcNo = $("#in_numberofPC").val();
  var group = $("#in_group").val();
console.log("pondo");
console.log(pondoID);
console.log(branchName);
console.log(pcNo);
console.log(group);

$.post("ajax/addBranch.php", {
        pondoID: pondoID,
        branchName: branchName,
        pcNo: pcNo,
        group: group
    }, function (data, status) {
        // console.log(data);
        $(".output").html(data);
        // read records again
        // readRecords();

        // clear fields from the popup
        // $("#first_name").val("");
        // $("#last_name").val("");
        // $("#email").val("");
    });
return false;
}

</script>
</html>
