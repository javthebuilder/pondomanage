<?php
include "db_connection.php";


$data = '<select name="group"  id="in_group"  class="field-select">';

$query = 'select storeid, storename from store where ParentID is null';
//<option value="Advertise">Advertise</option>
//<option value="Partnership">Partnership</option>
//<option value="General Question">General</option>
//</select>

$data .= '<option value="0">Select Group</option>';
$result = $conn->query($query);
		if ($result->num_rows > 0)
    {
			$number = 1;
			while($row = $result->fetch_assoc())
    	{
    		$data .= '<option value="'.$row['storeid'].'">'.$row['storename'].'</option>';
    		$number++;
    	}
    }
    else
    {
    	// records now found
    	$data .= '<tr><td colspan="6">Records not found!</td></tr>';
    }
    $data .= '</select>';

      echo $data;

 ?>
