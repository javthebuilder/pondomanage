<?php
include "db_connection.php";
$pondoID = (int)$_POST['pondoid'];

$data = '<select name="group"  id="in_group_update"  class="field-select" onchange="changegroup(this)">';

$query = "select storeid, storename from store where Type='Group'";
//<option value="Advertise">Advertise</option>
//<option value="Partnership">Partnership</option>
//<option value="General Question">General</option>
//</select>

$data .= '<option value="0">Select Group</option>';
$result = $conn->query($query);
		if ($result->num_rows > 0)
    {
			$number = 1;
			while($row = $result->fetch_assoc())
    	{
				if($row['storeid']==$pondoID){
					$data .= '<option value="'.$row['storeid'].'" selected>'.$row['storename'].'</option>';

				}
				else{
					$data .= '<option value="'.$row['storeid'].'">'.$row['storename'].'</option>';
				}
    		$number++;
    	}
    }
    else
    {
    	// records now found
    	$data .= '<tr><td colspan="6">Records not found!</td></tr>';
    }
    $data .= '</select>';

      echo $data;

 ?>
