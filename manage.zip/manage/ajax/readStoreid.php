<?php
  include "db_connection.php";
  $data="";
  $pondoID = (int)$_POST['pondoID'];
  $myObj = new \stdClass();
  $myObj->storeid=$pondoID;
  $data=$pondoID;
  if($pondoID!="" || $pondoID!=null){
    $query = 'select storeid, storename,type from store where storeid='.$pondoID;
    $result = $conn->query($query);
  	if ($result->num_rows > 0)
    {
  		$number = 1;

  		while($row = $result->fetch_assoc())
    	{
        // <label for="male">Male</label>
    		$data .= '<label value="'.$row['storeid'].'">'.$row['storename'].'</label>';

        $myObj->storename=$row['storename'];
        $myObj->type=$row['type'];
    		$number++;
    	}
      $myObj->status="success";
      $myJSON = json_encode($myObj);

      echo $myJSON;
    }
    else
    {
    	// records now found
    	// $data .= '<tr><td colspan="6">Records not found!</td></tr>';
      $myObj->status="fail";
      $myJSON = json_encode($myObj);
      echo $myJSON;
    }
  } else{
    $myObj->status="fail";
    $myJSON = json_encode($myObj);
    echo $myJSON;
  }
  // $data .= '</select>';

  // echo $data;

 ?>
