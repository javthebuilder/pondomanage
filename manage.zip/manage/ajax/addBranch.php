<?php
	if(isset($_POST['pondoID']) && isset($_POST['branchName']) && isset($_POST['group']))
	{
		// include Database connection file
		include("db_connection.php");

		// get values
		$pondoID = $_POST['pondoID'];
		$branchName = $_POST['branchName'];
		$pcNo = $_POST['pcNo'];
		$group = $_POST['group'];
		// echo "Pondo ID:" . $pondoID;
		// $query = "INSERT INTO store(StoreID) VALUES(".$pondoID.")";
 		// $query = "INSERT INTO store(StoreID, StoreName, PcCount, ParentID) VALUES(232323, 'Nitrogen', 12,7)";
// $query = "Select * from store where StoreID=13";



		$first_name = "jj23";
		$last_name = "halterbrand";
		$email = "gg@gmail.com";
		// $query = "INSERT INTO users(first_name, last_name, email) VALUES('$first_name', '$last_name', '$email')";
		$query = "INSERT INTO store(StoreID, StoreName, Displayname, PcCount, ParentID) VALUES($pondoID, '".$branchName."', '".$branchName."', $pcNo, $group)";


		if ($conn->query($query) === TRUE) {
			echo "Success Adding New Branch";
		}
		else {
    echo "Error: " . $query . "<br>" . $conn->error;}




		// $result = $conn->query($query);

		// if (!$result = mysql_query($query)) {
	  //       exit(mysql_error());
	  //   }

		//	$result = $conn->query($query);
			// echo "1 Record Added!";
			// if ($result->num_rows > 0) {
			// 	echo "1 Record Added!";
			// }
			// else {
			// 	echo "Failed Javar!";
			// }
				// mysql_close($conn);
$conn->close();
	}
?>
