<?php
include "db_connection.php";


$data = '<select name="branches"  id="edit_branches"  class="field-select" onchange="getval(this)">';

$query = "select storeid, storename from store where type like '%Branch%'";// where Type IS LIKE '%Branch%'";
//<option value="Advertise">Advertise</option>
//<option value="Partnership">Partnership</option>
//<option value="General Question">General</option>
//</select>

$data .= '<option value="0">Select Branch</option>';
$result = $conn->query($query);
// echo $result;
		if ($result->num_rows > 0)
    {
			$number = 1;
			while($row = $result->fetch_assoc())
    	{
    		$data .= '<option value="'.$row['storeid'].'"> '.$row['storeid'].' - '.$row['storename'].'</option>';
    		$number++;
    	}
    }
    else
    {
    	// records now found
    	$data .= '<tr><td colspan="6">Records not found!</td></tr>';
    }
    $data .= '</select>';

      echo $data;

 ?>
