<?php
  include "db_connection.php";
  $data="";
  $pondoID = (int)$_POST['pondoID'];
  $myObj = new \stdClass();
  $myObj->storeid=$pondoID;
  $data=$pondoID;
  if($pondoID!="" || $pondoID!=null){
    $query = 'select * from store where storeid='.$pondoID;
    $result = $conn->query($query);
  	if ($result->num_rows > 0)
    {
  		$number = 1;

  		while($row = $result->fetch_assoc())
    	{
        // <label for="male">Male</label>
    		// $data .= '<label value="'.$row['storeid'].'">'.$row['storename'].'</label>';
        $myObj->storeid=$pondoID;
        $myObj->storename=$row['StoreName'];
        $myObj->type=$row['Type'];
        $myObj->pccount=$row['PcCount'];
        $myObj->parentid=$row['ParentID'];
        $myObj->region=$row['Region'];
    		$number++;
    	}
      $myObj->status="success";
      $myJSON = json_encode($myObj);

      echo $myJSON;
    }
    else
    {
    	// records now found
    	// $data .= '<tr><td colspan="6">Records not found!</td></tr>';
      $myObj->status="fail";
      $myJSON = json_encode($myObj);
      echo $myJSON;
    }
  } else{
    $myObj->status="fail";
    $myJSON = json_encode($myObj);
    echo $myJSON;
  }
  // $data .= '</select>';

  // echo $data;

 ?>
