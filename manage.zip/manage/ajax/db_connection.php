<?php

// $servername = "webportal:3306";
// $username = "root";
// $password = "root";
// $database = "pondomanage";

$servername = "vadesystems.ddns.net:3307/pondomanage";
$username = "pondomanage";
$password = "#jnEj,a5fQ8B6:2u";
$database = "pondomanage";

$conn = new mysqli($servername, $username, $password,$database);
  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    $connect = false;
  }
  else{
    echo "";
    $connect = true;
  }

//  $servername = "webportal:3306";
// $username = "root";
// $password = "root";
// $database = "pondomanage";

// Connection variables
// $host = "localhost"; // MySQL host name eg. localhost
// $user = "root"; // MySQL user. eg. root ( if your on localserver)
//$password = ""; // MySQL user password  (if password is not set for your root user then keep it empty )
//$database = "users"; // MySQL Database name

// Connect to MySQL Database
//$db = mysql_connect($servername, $username, $password) or die("Could not connect to database");
// $mysqli = mysqli_connect($host, $user, $password, $database);

// Select MySQL Database
//mysql_select_db($database, $db);
// $servername = "webportal:3306";
// $username = "root";
// $password = "root";
// $database = "pondomanage";
//
// $databaseHost = $servername;
// $databaseName = $database;
// $databaseUsername = 'root';
// $databasePassword = 'root';
//
// $mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);

?>
