<html>
<title>
</title>
  <head>
    <link rel="stylesheet" type="text/css" href="branch_add_style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css" />
    <link rel="stylesheet" href="http://raw.github.com/daneden/animate.css/master/animate.css" type="text/css" />

    <link rel="stylesheet" href="dist/rmodal.css" type="text/css" />
    <script type="text/javascript" src="dist/rmodal.js"></script>
    <script type="text/javascript">
      window.onload = function() {
          var modal = new RModal(document.getElementById('modal_add'), {
              beforeOpen: function(next) {
                  console.log('beforeOpen');
                  next();
              }
              , afterOpen: function() {
                  console.log('opened');
              }

              , beforeClose: function(next) {
                  console.log('beforeClose');
                  next();
              }
              , afterClose: function() {
                  console.log('closed on add');
                  $(".output").html("");
              }

              // , content: 'Abracadabra'

              // , bodyClass: 'modal-open'
              // , dialogClass: 'modal-dialog-lg'
              , dialogOpenClass: 'fadeIn'
              , dialogCloseClass: 'fadeOut'

              // , focus: true
              // , focusElements: ['input.form-control', 'textarea', 'button.btn-primary']

              , escapeClose: true
          });
          var modal_edit= new RModal(document.getElementById('modal_update'), {
              beforeOpen: function(next) {
                  console.log('beforeOpen edit');
                  next();
              }
              , afterOpen: function() {
                  console.log('opened edit');
                  console.log("oopen afteropen");
                  readBranch();
              }

              , beforeClose: function(next) {
                  console.log('beforeClose edit');
                  next();
              }
              , afterClose: function() {
                  console.log('closed edit');
              }

              // , content: 'Abracadabra'

              // , bodyClass: 'modal-open'
              // , dialogClass: 'modal-dialog-lg'
              // , dialogOpenClass: 'fadeIn'
              // , dialogCloseClass: 'fadeOut'

              // , focus: true
              // , focusElements: ['input.form-control', 'textarea', 'button.btn-primary']

              // , escapeClose: true
          });
          document.addEventListener('keydown', function(ev) {
              modal.keydown(ev);
          }, false);

          document.getElementById('showModal').addEventListener("click", function(ev) {
              ev.preventDefault();
              modal.open();
          }, false);

          document.addEventListener('keydown', function(ev) {
              modal_edit.keydown(ev);
          }, false);
          document.getElementById('showModal_edit').addEventListener("click", function(ev) {
              ev.preventDefault();
              modal_edit.open();
              $("#in_branchName_update").prop('disabled', true);
              $("#in_numberofPC_update").prop('disabled', true);
              $("#in_branchName_update").prop('value', "");
              $("#in_numberofPC_update").prop('value', "");
              $(".group_update").hide();
              // readBranch();
              // $("group_update").hide();
              // console.log("oopen");
          }, false);

          window.modal = modal;
          window.modal_update =modal_edit;
      }
  </script>

  </head>
  <body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <a href="#" id="showModal" class="btn btn-success">Add Branch</a>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <a href="#" id="showModal_edit" class="btn btn-warning">Edit Branch</a>
            </div>
        </div>
    </div>

<div id="modal_add" class="modal">
        <div class="modal-dialog animated">
            <div class="modal-content">
                <form class="form-horizontal" method="get">
                    <div class="modal-header">
                        <strong>Add Branch</strong>
                        <button type="button" class="close" data-dismiss="modal" onclick="modal.close();">&times;</button>
                    </div>

                    <!-- <div class="modal-body"> -->
                      <div class="modal-body">
                        <div class="form-group">
                            <!-- <label for="dummyText" class="control-label col-xs-4">Dummy text</label> -->
                            <!-- <div class="input-group col-xs-7"> -->
                            <!-- <div class="form-group"> -->
                                <!-- <input type="text" name="dummyText" id="dummyText" class="form-control" /> -->
                                <!-- <div class="center"> -->
                                <!-- <form> -->
                                <!-- <ul class="form-style-1"> -->
                                <ul class="form-style-1">
                                    <li>
                                        <label>Pondo ID <span class="required">*</span></label>
                                        <input id="in_pondoID" type="text" name="pondoID" class="field-divided" placeholder="ID" />
                                        <div class="output" id="pondoid_check">
                                        </div>
                                    </li>
                                    <li>
                                      <label>Branch Name <span class="required">*</span></label>
                                      <input id="in_branchName" type="text" name="branchName" class="field-divided" placeholder="Branch Name" /></li>

                                    <li>
                                        <label>Number of PC <span class="required">*</span></label>
                                        <input id="in_numberofPC" type="text" name="field3" class="field-divided" placeholder="Number of PC" required/>
                                    </li>
                                    <li>
                                        <label>Group</label>
                                        <div class="group"></div>
                                    </li>

                                    <li>
                                        <!-- <input type="Submit" value="Add Branch" onclick="return addBranch();"/> -->
                                    </li>
                                    <li>
                                      <div class="output"></div>
                                    </li>

                                </ul>

                                <!-- </form> -->
                              <!-- </div> -->
                            <!-- </div> -->
                        </div>
                        <!-- <input class="datepicker" data-date-format="mm/dd/yyyy"> -->
                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-default" type="button" onclick="modal.close();">Cancel</button>
                        <button class="btn btn-primary" type="submit" onclick="return addBranch();">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div id="modal_update" class="modal">
            <div class="modal-dialog animated">
                <div class="modal-content">
                    <form class="form-horizontal" method="get">
                        <div class="modal-header">
                            <strong>Edit Branch</strong>
                            <button type="button" class="close" data-dismiss="modal" onclick="modal_update.close();">&times;</button>
                        </div><div class="modal-body">
                            <div class="form-group">
                                    <ul class="form-style-1">
                                        <li>
                                            <label>Pondo ID <span class="required">*</span></label>
                                            <div class="output" id="branches"></div>
                                            <input id="in_storeid_update" type="hidden" name="branchName_update" class="field-divided" placeholder="" /></li>
                                        </li>
                                        <li>
                                          <label>Branch Name <span class="required">*</span></label>
                                          <input id="in_branchName_update" type="text" name="branchName_update" class="field-divided" placeholder="Branch Name" /></li>

                                        <li>
                                            <label>Number of PC <span class="required">*</span></label>
                                            <input id="in_numberofPC_update" type="text" name="field3" class="field-divided" placeholder="Number of PC" required/>
                                        </li>
                                        <li>
                                            <label>Group</label>
                                            <div class="group_update"></div>
                                            <input id="in_group_update_text" type="hidden" name="branchName_update" class="field-divided" placeholder="" /></li>
                                        </li>
                                        <li>
                                          <div class="output_update"></div>
                                        </li>
                                  </ul>

                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-default" type="button" onclick="modal_update.close();">Cancel</button>
                            <button class="btn btn-primary" type="submit" onclick="return updateBranch();">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
</body>
<script>
$(document).ready(function () {
    readRecords(); // calling function
    // $.fn.datepicker.defaults.format = "mm/dd/yyyy";
    // $('.datepicker').datepicker({
    //     startDate: '-3d'
    // });
    var selecedId ;
    $("#in_pondoID").keyup(function(){
      console.log("keyup " + $("#in_pondoID").val());
      var searchID = $("#in_pondoID").val();
      $.post("ajax/readStoreid.php", {
              pondoID: searchID
          }, function (data, status) {
              console.log(data + " st:" + status);
              // $("#pondoid_check").html(data);
              obj = JSON.parse(data);
              if(obj.status=="success"){
                $("#pondoid_check").html("<span class='glyphicon glyphicon-warning-sign big' style='color:red'> ID Already in used, " +
                 obj.storeid + " - " + obj.storename + " type:" + obj.type + "</span>");

                // $("<span>Hello world!</span>").insertAfter("p");
                console.log(obj.storeid);
                console.log(obj.storename);
                console.log(obj.type);
              }else{
                console.log("fail");
                $("#pondoid_check").html("");
                $("output").html("");
              }

          });

    	// console.log($("#in_pondoID").val());

    });
    // $('#edit_branches').on('change', function() {
    //   console.log($("#edit_branches").val());
    // })
});
// function findID(){
//
//
// }
function getval(sel)
{
    // alert(sel.value);
    if(sel.value==0){
      $("#in_branchName_update").val("");
      $("#in_branchName_update").prop('disabled', true);
      $("#in_numberofPC_update").prop('disabled', true);
    }else{
      selecedId = sel.value;
      $.post("ajax/getStoreInfo.php", {
        pondoID:selecedId
      }, function (data, status) {
        // $(".group_update").html(data);
            console.log(data);;
          obj = JSON.parse(data);
          //datadata=data;
          console.log(obj);
          // $(".group").html(data);
          $("#in_branchName_update").prop('disabled', false);
          $("#in_branchName_update").val(obj.storename);
          $("#in_numberofPC_update").prop('disabled', false);
          $("#in_numberofPC_update").val(obj.pccount);
          // $("#in_group_update").prop('disabled', true);
          // $(".group_update").prop('visible', false);
          // console.log(obj.parentid);
          $("#in_group_update_text").val(obj.parentid);
          $("#in_storeid_update").val(obj.storeid);

          $(".group_update").show();
          var groupid = obj.parentid;

          getGroup(groupid);


      });
       // $("#in_group_update").val("257");
       // $(function() {
       //     $("#update_option").filter(function() {
       //        ($("#update_option").value() == 5); //To select Blue
       //     }).prop('selected', true);
       // });
    }
}
function readRecords() {
    var datadata="";
    $.post("ajax/readGroups.php", {
    }, function (data, status) {
        $(".group").html(data);
    });
}
function getGroup(storeid) {
    var datadata="";
    $.post("ajax/getGroup.php", {
      pondoid:storeid
    }, function (data, status) {
        // console.log("data from group:" + data);
        $(".group_update").html(data);
    });
}

function readBranch(){
  $.post("ajax/readBranches.php",{
  },function(data,status){
    $("#branches").html(data);
  });
}
function show_confirm()
{
     var r=confirm("Do You Really want to Refund money! Press ok to Continue ");
     if (r==true)
       {
       window.location="yourphppage.php";
       return true;
       }
          else
       {
       alert("You pressed Cancel!");
       }
}
function addBranch() {

  var pondoID = $("#in_pondoID").val();
  var branchName = $("#in_branchName").val();
  var pcNo = $("#in_numberofPC").val();
  var group = $("#in_group").val();
  console.log("pondo");
  console.log("pondo ID: " + pondoID);
  console.log("Name" + branchName);
  console.log("PCNO" + pcNo);
  console.log("Group" + group);
  if(pondoID==""){
    console.log("missing Id");
    $(".output").html("<span class='glyphicon glyphicon-warning-sign big' style='color:red'> Missing Store ID </span>");
  } else if (branchName=="") {
    console.log("Missing Branch Name");
    $(".output").html("<span class='glyphicon glyphicon-warning-sign big' style='color:red'> Missing Branch Name </span>");
  } else if (pcNo=='' || pcNo <= 0) {
    console.log("missing Pc No.");
    $(".output").html("<span class='glyphicon glyphicon-warning-sign big' style='color:red'> Missing PC Number </span>");
  } else if (group == 0 || group == "") {
    console.log("Select a Group");
    $(".output").html("<span class='glyphicon glyphicon-warning-sign big' style='color:red'> Select a group </span>");
  } else {
    $.post("ajax/addBranch.php", {
            pondoID: pondoID,
            branchName: branchName,
            pcNo: pcNo,
            group: group
        }, function (data, status) {
            $(".output").html(data);
        });
  }return false;
}
function updateBranch(){
// $("output").value(sel);
  console.log("Storeid:" + $("#in_storeid_update").val());
  console.log("Name:" + $("#in_branchName_update").val());
  console.log("Pc No:" + $("#in_numberofPC_update").val());
  console.log("Group:" + $("#in_group_update_text").val());
  var pondoID = $("#in_storeid_update").val();
  var branchName = $("#in_branchName_update").val();
  var pcNo = $("#in_numberofPC_update").val();
  var group = $("#in_group_update_text").val();
  console.log("pondo");
  console.log("pondo ID: " + pondoID);
  console.log("Name" + branchName);
  console.log("PCNO" + pcNo);
  console.log("Group" + group);
  if(pondoID==""){
    console.log("missing Id");
    $(".output").html("<span class='glyphicon glyphicon-warning-sign big' style='color:red'> Missing Store ID </span>");
  } else if (branchName=="") {
    console.log("Missing Branch Name");
    $(".output").html("<span class='glyphicon glyphicon-warning-sign big' style='color:red'> Missing Branch Name </span>");
  } else if (pcNo=='' || pcNo <= 0) {
    console.log("missing Pc No.");
    $(".output").html("<span class='glyphicon glyphicon-warning-sign big' style='color:red'> Missing PC Number </span>");
  } else if (group == 0 || group == "") {
    console.log("Select a Group");
    $(".output").html("<span class='glyphicon glyphicon-warning-sign big' style='color:red'> Select a group </span>");
  } else {
    $.post("ajax/updateBranch.php", {
            pondoID: pondoID,
            branchName: branchName,
            pcNo: pcNo,
            group: group
        }, function (data, status) {
            $(".output_update").html(data);
        });
  }return false;



  return false;

}
function changegroup(sel){
  var selectedGroup = sel.value;
  console.log("Selected Group" + selectedGroup);
  $("#in_group_update_text").val(selectedGroup);
}


</script>
</html>
